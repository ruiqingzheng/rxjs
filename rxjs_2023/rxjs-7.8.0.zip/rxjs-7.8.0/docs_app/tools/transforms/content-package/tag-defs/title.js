module.exports = function() {
  return {name: 'title'};
};
