module.exports = function() {
  return {name: 'noDescription', transforms: function() { return true; }};
};