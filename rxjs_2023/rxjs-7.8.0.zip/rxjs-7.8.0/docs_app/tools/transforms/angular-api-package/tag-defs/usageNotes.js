module.exports = function() {
  return {
    name: 'usageNotes'
  };
};
