module.exports = function() {
  return {name: 'security'};
};
