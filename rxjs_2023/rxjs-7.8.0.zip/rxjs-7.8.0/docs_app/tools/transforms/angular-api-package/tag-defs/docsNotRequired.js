module.exports = function() {
  return {name: 'docsNotRequired'};
};
