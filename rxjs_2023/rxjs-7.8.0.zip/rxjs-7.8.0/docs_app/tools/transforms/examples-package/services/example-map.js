module.exports = function exampleMap() {
  return {};
};
